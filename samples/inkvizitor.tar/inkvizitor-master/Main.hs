import qualified Inkvizitor.UI.Main

main = Inkvizitor.UI.Main.main
